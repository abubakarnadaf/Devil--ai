DEVIL AI Website Starter
========================

Files:
- index.html — self-contained mobile-friendly DEVIL AI prototype.

How to use on Redmi 7A:
1. Download and extract the ZIP, or open index.html from your phone's file manager.
2. For best compatibility, upload index.html to a trusted static website host or open it in an updated browser.
3. Open the page in Chrome, allow microphone permission if asked, and tap TAP TO TALK.
4. You can also type questions.

What it does:
- Futuristic mobile UI.
- Hindi, English (India), and Kannada language choices.
- Browser speech recognition where supported.
- Browser text-to-speech where supported.
- Limited local demo replies.

What it does not do yet:
- It is not a real AI chatbot yet.
- It does not have a working always-on "Hey Devil" wake word.
- It does not access the camera or control the whole phone.
- It does not include an API key.

For real AI:
A secure server/backend must be added to call an AI provider. Never place private API keys in public HTML or JavaScript.
